package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class User {
    private int id;
    private String name;
    private String zhangtai;
    private String XM;
    private Date jiezhiriqi;
    public User() {
        super();
    }
    public User(String name, String zhangtai, String XM, Date jiezhiriqi) {
        super();
        this.name = name;
        this.zhangtai = zhangtai;
        this.XM = XM;
        this.jiezhiriqi = jiezhiriqi;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getzhangtai() {
        return zhangtai;
    }
    public void setzhangtai(String zhangtai) {
        this.zhangtai = zhangtai;
    }
    public String getXM() {
        return XM;
    }
    public void setXM(String XM) {
        this.XM = XM;
    }
    public Date getjiezhiriqi() {
        return jiezhiriqi;
    }
    public void setjiezhiriqi(Date jiezhiriqi) {
        this.jiezhiriqi = jiezhiriqi;
    }
    public void setjiezhiriqi(String jiezhiriqi) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(jiezhiriqi);
            this.jiezhiriqi=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.jiezhiriqi=null;
        }

    }
    @Override
    public String toString() {
        return "User [id=" + id + ", name=" + name + ", zhangtai=" + zhangtai + ", XM=" + XM + ", jiezhiriqi=" + jiezhiriqi
                + "]";
    }
}