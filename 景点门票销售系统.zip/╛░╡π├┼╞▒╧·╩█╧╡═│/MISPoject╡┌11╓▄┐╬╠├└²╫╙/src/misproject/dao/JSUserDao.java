package misproject.dao;

import misproject.pojo.JSUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 * 对JSUser表的浏览、查询、添加、修改、删除操作
 */
public class JSUserDao {
    /**
     * 对JSUser表的浏览操作
     */
    public static List<JSUser> allJSUsers() {
        List<JSUser> JSUsers=new ArrayList<JSUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from JQ";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                JSUser JSUser=new JSUser();
                JSUser.setId(rs.getInt("id"));
                JSUser.setName(rs.getString("name"));
                JSUser.setsex(rs.getString("sex"));
                JSUser.setxiangmu(rs.getString("xiangmu"));
                JSUser.setbirthday(rs.getDate("birthday"));
                JSUsers.add(JSUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return JSUsers;
    }
    /**
     * 对JSUser表的查询操作，按照name值查询
     */
    public static List<JSUser> queryJSUsersByName(String name) {
        List<JSUser> JSUsers=new ArrayList<JSUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from JQ where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                JSUser JSUser=new JSUser();
                JSUser.setId(rs.getInt("id"));
                JSUser.setName(rs.getString("name"));
                JSUser.setsex(rs.getString("sex"));
                JSUser.setxiangmu(rs.getString("xiangmu"));
                JSUser.setbirthday(rs.getDate("birthday"));
                JSUsers.add(JSUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return JSUsers;
    }
    /**
     * 对JSUser表的查询操作，按照name和sex值查询
     */
    public static List<JSUser> queryJSUsersByNameAndsex(String name,String sex) {
        List<JSUser> JSUsers=new ArrayList<JSUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from JQ where name like '%"+name+"%' and sex='"+sex+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                JSUser JSUser=new JSUser();
                JSUser.setId(rs.getInt("id"));
                JSUser.setName(rs.getString("name"));
                JSUser.setsex(rs.getString("sex"));
                JSUser.setxiangmu(rs.getString("xiangmu"));
                JSUser.setbirthday(rs.getDate("birthday"));
                JSUsers.add(JSUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return JSUsers;
    }
    /**
     * 对JSUser表的查询操作，按照id值查询
     */
    public static JSUser queryJSUsersById(int id) {
        JDBC jdbc=new JDBC();
        JSUser JSUser=null;
        try {
            jdbc.startConnection();
            String sql = "select * from  JQ where id="+id;
            ResultSet rs=jdbc.query(sql);
            if(rs.next()) {
                JSUser=new JSUser();
                JSUser.setId(rs.getInt("id"));
                JSUser.setName(rs.getString("name"));
                JSUser.setsex(rs.getString("sex"));
                JSUser.setxiangmu(rs.getString("xiangmu"));
                JSUser.setbirthday(rs.getDate("birthday"));
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return JSUser;
    }
    /**
     * 对JSUser表的添加操作
     */
    public static int insertJSUser(JSUser JSUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into JQ(name,sex,xiangmu,birthday) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, JSUser.getName());
            pStatement.setString(2,JSUser.getsex());
            pStatement.setString(3, JSUser.getxiangmu());
            pStatement.setDate(4, JSUser.getbirthday());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对JSUser表的修改操作
     */
    public static int updateJSUserxiangmu(String xiangmu,int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update JQ set xiangmu='"+xiangmu+"' where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对JSUser表的修改操作
     */
    public static int updateJSUser(JSUser JSUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update JQ set name=?,sex=?,xiangmu=?,birthday=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, JSUser.getName());
            pStatement.setString(2,JSUser.getsex());
            pStatement.setString(3, JSUser.getxiangmu());
            pStatement.setDate(4, JSUser.getbirthday());
            pStatement.setInt(5, JSUser.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对JSUser表的删除操作
     */
    public static int deleteJSUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from JQ where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
