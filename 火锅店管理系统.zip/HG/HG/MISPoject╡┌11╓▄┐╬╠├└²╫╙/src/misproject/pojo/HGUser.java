package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class HGUser {
    private int id;
    private String name;
    private String leibie;
    private String miaoshu;
    private Date diancaishijian;
    public HGUser() {
        super();
    }
    public HGUser(String name, String leibie, String miaoshu, Date diancaishijian) {
        super();
        this.name = name;
        this.leibie = leibie;
        this.miaoshu = miaoshu;
        this.diancaishijian = diancaishijian;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getleibie() {
        return leibie;
    }
    public void setleibie(String leibie) {
        this.leibie = leibie;
    }
    public String getmiaoshu() {
        return miaoshu;
    }
    public void setmiaoshu(String miaoshu) {
        this.miaoshu = miaoshu;
    }
    public Date getdiancaishijian() {
        return diancaishijian;
    }
    public void setdiancaishijian(Date diancaishijian) {
        this.diancaishijian = diancaishijian;
    }
    public void setdiancaishijian(String diancaishijian) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(diancaishijian);
            this.diancaishijian=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.diancaishijian=null;
        }

    }
    @Override
    public String toString() {
        return "HGUser [id=" + id + ", name=" + name + ", leibie=" + leibie + ", miaoshu=" + miaoshu + ", diancaishijian=" + diancaishijian
                + "]";
    }
}