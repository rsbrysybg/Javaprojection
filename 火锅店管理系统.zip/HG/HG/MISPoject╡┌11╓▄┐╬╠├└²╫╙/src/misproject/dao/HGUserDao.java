package misproject.dao;

import misproject.pojo.HGUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 * 对HGUser表的浏览、查询、添加、修改、删除操作
 */
public class HGUserDao {
    /**
     * 对HGUser表的浏览操作
     */
    public static List<HGUser> allHGUsers() {
        List<HGUser> HGUsers=new ArrayList<HGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from xuancai";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                HGUser HGUser=new HGUser();
                HGUser.setId(rs.getInt("id"));
                HGUser.setName(rs.getString("name"));
                HGUser.setleibie(rs.getString("leibie"));
                HGUser.setmiaoshu(rs.getString("miaoshu"));
                HGUser.setdiancaishijian(rs.getDate("diancaishijian"));
                HGUsers.add(HGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return HGUsers;
    }
    /**
     * 对HGUser表的查询操作，按照name值查询
     */
    public static List<HGUser> queryHGUsersByName(String name) {
        List<HGUser> HGUsers=new ArrayList<HGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from xuancai where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                HGUser HGUser=new HGUser();
                HGUser.setId(rs.getInt("id"));
                HGUser.setName(rs.getString("name"));
                HGUser.setleibie(rs.getString("leibie"));
                HGUser.setmiaoshu(rs.getString("miaoshu"));
                HGUser.setdiancaishijian(rs.getDate("diancaishijian"));
                HGUsers.add(HGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return HGUsers;
    }
    /**
     * 对HGUser表的查询操作，按照name和leibie值查询
     */
    public static List<HGUser> queryHGUsersByNameAndleibie(String name,String leibie) {
        List<HGUser> HGUsers=new ArrayList<HGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from xuancai where name like '%"+name+"%' and leibie='"+leibie+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                HGUser HGUser=new HGUser();
                HGUser.setId(rs.getInt("id"));
                HGUser.setName(rs.getString("name"));
                HGUser.setleibie(rs.getString("leibie"));
                HGUser.setmiaoshu(rs.getString("miaoshu"));
                HGUser.setdiancaishijian(rs.getDate("diancaishijian"));
                HGUsers.add(HGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return HGUsers;
    }
    /**
     * 对HGUser表的查询操作，按照id值查询
     */
    public static HGUser queryHGUsersById(int id) {
        JDBC jdbc=new JDBC();
        HGUser HGUser=null;
        try {
            jdbc.startConnection();
            String sql = "select * from  xuancai where id="+id;
            ResultSet rs=jdbc.query(sql);
            if(rs.next()) {
                HGUser=new HGUser();
                HGUser.setId(rs.getInt("id"));
                HGUser.setName(rs.getString("name"));
                HGUser.setleibie(rs.getString("leibie"));
                HGUser.setmiaoshu(rs.getString("miaoshu"));
                HGUser.setdiancaishijian(rs.getDate("diancaishijian"));
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return HGUser;
    }
    /**
     * 对HGUser表的添加操作
     */
    public static int insertHGUser(HGUser HGUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into xuancai(name,leibie,miaoshu,diancaishijian) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, HGUser.getName());
            pStatement.setString(2,HGUser.getleibie());
            pStatement.setString(3, HGUser.getmiaoshu());
            pStatement.setDate(4, HGUser.getdiancaishijian());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对HGUser表的修改操作
     */
    public static int updateHGUsermiaoshu(String miaoshu,int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update xuancai set miaoshu='"+miaoshu+"' where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对HGUser表的修改操作
     */
    public static int updateHGUser(HGUser HGUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update xuancai set name=?,leibie=?,miaoshu=?,diancaishijian=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, HGUser.getName());
            pStatement.setString(2,HGUser.getleibie());
            pStatement.setString(3, HGUser.getmiaoshu());
            pStatement.setDate(4, HGUser.getdiancaishijian());
            pStatement.setInt(5, HGUser.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对HGUser表的删除操作
     */
    public static int deleteHGUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from xuancai where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
