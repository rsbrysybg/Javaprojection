package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class JXUser {
    private int id;
    private String name;
    private String sex;
    private String miaoshu;
    private Date shengri;
    public JXUser() {
        super();
    }
    public JXUser(String name, String sex, String miaoshu, Date shengri) {
        super();
        this.name = name;
        this.sex = sex;
        this.miaoshu = miaoshu;
        this.shengri = shengri;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getsex() {
        return sex;
    }
    public void setsex(String sex) {
        this.sex = sex;
    }
    public String getmiaoshu() {
        return miaoshu;
    }
    public void setmiaoshu(String miaoshu) {
        this.miaoshu = miaoshu;
    }
    public Date getshengri() {
        return shengri;
    }
    public void setshengri(Date shengri) {
        this.shengri = shengri;
    }
    public void setshengri(String shengri) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(shengri);
            this.shengri=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.shengri=null;
        }

    }
    @Override
    public String toString() {
        return "JXUser [id=" + id + ", name=" + name + ", sex=" + sex + ", miaoshu=" + miaoshu + ", shengri=" + shengri
                + "]";
    }
}