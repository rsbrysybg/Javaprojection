package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class User {
    private int id;
    private String name;
    private String sex;
    private String gekechengji;
    private Date kaoshiriqi;
    public User() {
        super();
    }
    public User(String name, String sex, String gekechengji, Date kaoshiriqi) {
        super();
        this.name = name;
        this.sex = sex;
        this.gekechengji = gekechengji;
        this.kaoshiriqi = kaoshiriqi;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getgekechengji() {
        return gekechengji;
    }
    public void setgekechengji(String gekechengji) {
        this.gekechengji = gekechengji;
    }
    public Date getkaoshiriqi() {
        return kaoshiriqi;
    }
    public void setkaoshiriqi(Date kaoshiriqi) {
        this.kaoshiriqi = kaoshiriqi;
    }
    public void setkaoshiriqi(String kaoshiriqi) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(kaoshiriqi);
            this.kaoshiriqi=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.kaoshiriqi=null;
        }

    }
    @Override
    public String toString() {
        return "User [id=" + id + ", name=" + name + ", sex=" + sex + ", gekechengji=" + gekechengji + ", kaoshiriqi=" + kaoshiriqi
                + "]";
    }
}