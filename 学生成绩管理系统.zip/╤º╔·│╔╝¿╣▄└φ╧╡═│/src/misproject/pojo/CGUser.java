package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class CGUser {
    private int id;
    private String name;
    private String sex;
    private String qingkuang;
    private Date kaoshiriqi;
    public CGUser() {
        super();
    }
    public CGUser(String name, String sex, String qingkuang, Date kaoshiriqi) {
        super();
        this.name = name;
        this.sex = sex;
        this.qingkuang = qingkuang;
        this.kaoshiriqi = kaoshiriqi;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getsex() {
        return sex;
    }
    public void setsex(String sex) {
        this.sex = sex;
    }
    public String getqingkuang() {
        return qingkuang;
    }
    public void setqingkuang(String qingkuang) {
        this.qingkuang = qingkuang;
    }
    public Date getkaoshiriqi() {
        return kaoshiriqi;
    }
    public void setkaoshiriqi(Date kaoshiriqi) {
        this.kaoshiriqi = kaoshiriqi;
    }
    public void setkaoshiriqi(String kaoshiriqi) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(kaoshiriqi);
            this.kaoshiriqi=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.kaoshiriqi=null;
        }

    }
    @Override
    public String toString() {
        return "CGUser [id=" + id + ", name=" + name + ", sex=" + sex + ", qingkuang=" + qingkuang + ", kaoshiriqi=" + kaoshiriqi
                + "]";
    }
}