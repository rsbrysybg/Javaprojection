/*
 * Created by JFormDesigner on Mon Apr 29 11:33:04 CST 2024
 */

package misproject.window;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * @author Administrator
 */
public class MainCG extends JFrame {
    public static void  main(String[] args) {
        new MainCG();
    }
    public MainCG() {
        initComponents();
    }


    private void CGEdit(ActionEvent e) {
        new CGEdit(this).setVisible(true);
    }






    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents  @formatter:off
        toolBar1 = new JToolBar();
        button2 = new JButton();

        //======== this ========
        setPreferredSize(new Dimension(1200, 800));
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("\u5b66\u751f\u6210\u7ee9\u7cfb\u7edf-\u6559\u5e08\u754c\u9762");
        var contentPane = getContentPane();
        contentPane.setLayout(null);

        //======== toolBar1 ========
        {
            toolBar1.setFont(new Font("\u7b49\u7ebf", Font.PLAIN, 16));

            //---- button2 ----
            button2.setIcon(UIManager.getIcon("FileChooser.listViewIcon"));
            button2.setFont(new Font("\u7b49\u7ebf", Font.PLAIN, 16));
            button2.addActionListener(e -> CGEdit(e));
            toolBar1.add(button2);
            toolBar1.addSeparator();
        }
        contentPane.add(toolBar1);
        toolBar1.setBounds(new Rectangle(new Point(0, 0), toolBar1.getPreferredSize()));

        {
            // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents  @formatter:on
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables  @formatter:off
    private JToolBar toolBar1;
    private JButton button2;
    // JFormDesigner - End of variables declaration  //GEN-END:variables  @formatter:on
}
