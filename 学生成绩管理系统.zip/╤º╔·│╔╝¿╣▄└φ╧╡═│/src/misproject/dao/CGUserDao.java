package misproject.dao;

import misproject.pojo.CGUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 * 对CGUser表的浏览、查询、添加、修改、删除操作
 */
public class CGUserDao {
    /**
     * 对CGUser表的浏览操作
     */
    public static List<CGUser> allCGUsers() {
        List<CGUser> CGUsers=new ArrayList<CGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from Student";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CGUser CGUser=new CGUser();
                CGUser.setId(rs.getInt("id"));
                CGUser.setName(rs.getString("name"));
                CGUser.setsex(rs.getString("sex"));
                CGUser.setqingkuang(rs.getString("qingkuang"));
                CGUser.setkaoshiriqi(rs.getDate("kaoshiriqi"));
                CGUsers.add(CGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CGUsers;
    }
    /**
     * 对CGUser表的查询操作，按照name值查询
     */
    public static List<CGUser> queryCGUsersByName(String name) {
        List<CGUser> CGUsers=new ArrayList<CGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from Student where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CGUser CGUser=new CGUser();
                CGUser.setId(rs.getInt("id"));
                CGUser.setName(rs.getString("name"));
                CGUser.setsex(rs.getString("sex"));
                CGUser.setqingkuang(rs.getString("qingkuang"));
                CGUser.setkaoshiriqi(rs.getDate("kaoshiriqi"));
                CGUsers.add(CGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CGUsers;
    }
    /**
     * 对CGUser表的查询操作，按照name和sex值查询
     */
    public static List<CGUser> queryCGUsersByNameAndsex(String name,String sex) {
        List<CGUser> CGUsers=new ArrayList<CGUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from Student where name like '%"+name+"%' and sex='"+sex+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CGUser CGUser=new CGUser();
                CGUser.setId(rs.getInt("id"));
                CGUser.setName(rs.getString("name"));
                CGUser.setsex(rs.getString("sex"));
                CGUser.setqingkuang(rs.getString("qingkuang"));
                CGUser.setkaoshiriqi(rs.getDate("kaoshiriqi"));
                CGUsers.add(CGUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CGUsers;
    }
    /**
     * 对CGUser表的查询操作，按照id值查询
     */
    public static CGUser queryCGUsersById(int id) {
        JDBC jdbc=new JDBC();
        CGUser CGUser=null;
        try {
            jdbc.startConnection();
            String sql = "select * from  Student where id="+id;
            ResultSet rs=jdbc.query(sql);
            if(rs.next()) {
                CGUser=new CGUser();
                CGUser.setId(rs.getInt("id"));
                CGUser.setName(rs.getString("name"));
                CGUser.setsex(rs.getString("sex"));
                CGUser.setqingkuang(rs.getString("qingkuang"));
                CGUser.setkaoshiriqi(rs.getDate("kaoshiriqi"));
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CGUser;
    }
    /**
     * 对CGUser表的添加操作
     */
    public static int insertCGUser(CGUser CGUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into Student(name,sex,qingkuang,kaoshiriqi) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, CGUser.getName());
            pStatement.setString(2,CGUser.getsex());
            pStatement.setString(3, CGUser.getqingkuang());
            pStatement.setDate(4, CGUser.getkaoshiriqi());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CGUser表的修改操作
     */
    public static int updateCGUserqingkuang(String qingkuang,int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update Student set qingkuang='"+qingkuang+"' where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CGUser表的修改操作
     */
    public static int updateCGUser(CGUser CGUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update Student set name=?,sex=?,qingkuang=?,kaoshiriqi=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, CGUser.getName());
            pStatement.setString(2,CGUser.getsex());
            pStatement.setString(3, CGUser.getqingkuang());
            pStatement.setDate(4, CGUser.getkaoshiriqi());
            pStatement.setInt(5, CGUser.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CGUser表的删除操作
     */
    public static int deleteCGUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from Student where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
