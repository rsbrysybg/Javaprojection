/*
Navicat MySQL Data Transfer

Source Server         : Wjl
Source Server Version : 80034
Source Host           : localhost:3306
Source Database       : jdbc

Target Server Type    : MYSQL
Target Server Version : 80034
File Encoding         : 65001

Date: 2024-04-29 09:40:16
*/

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `JQ` (
                      `Id` INT NOT NULL AUTO_INCREMENT,
                      `name` VARCHAR(9) DEFAULT NULL,
                      `sex` VARCHAR(2) DEFAULT NULL,
                      `xiangmu` VARCHAR(50) DEFAULT NULL,
                      `birthday` DATE DEFAULT NULL,
                      PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

CREATE TABLE `GK` (
                      `Id` INT NOT NULL AUTO_INCREMENT,
                      `name` VARCHAR(9) DEFAULT NULL,
                      `zhangtai` VARCHAR(2) DEFAULT NULL,
                      `XM` VARCHAR(50) DEFAULT NULL,
                      `jiezhiriqi` DATE DEFAULT NULL,
                      PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

create table users
(
    id       int auto_increment
        primary key,
    name     varchar(40) null,
    password varchar(40) null,
    email    varchar(60) null,
    birthday date        null
)
    charset = utf8mb3;
