package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class User {
    private int id;
    private String name;
    private String sex;
    private String duiyuan;
    private Date birthday;
    public User() {
        super();
    }
    public User(String name, String sex, String duiyuan, Date birthday) {
        super();
        this.name = name;
        this.sex = sex;
        this.duiyuan = duiyuan;
        this.birthday = birthday;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getsex() {
        return sex;
    }
    public void setsex(String sex) {
        this.sex = sex;
    }
    public String getduiyuan() {
        return duiyuan;
    }
    public void setduiyuan(String duiyuan) {
        this.duiyuan = duiyuan;
    }
    public Date getbirthday() {
        return birthday;
    }
    public void setbirthday(Date birthday) {
        this.birthday = birthday;
    }
    public void setbirthday(String birthday) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(birthday);
            this.birthday=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.birthday=null;
        }

    }
    @Override
    public String toString() {
        return "User [id=" + id + ", name=" + name + ", sex=" + sex + ", duiyuan=" + duiyuan + ", birthday=" + birthday
                + "]";
    }
}