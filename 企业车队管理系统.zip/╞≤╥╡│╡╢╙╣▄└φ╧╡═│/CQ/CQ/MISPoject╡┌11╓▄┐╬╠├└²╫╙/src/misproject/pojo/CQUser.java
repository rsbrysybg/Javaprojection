package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class CQUser {
    private int id;
    private String name;
    private String zhangtai;
    private String qingkuang;
    private Date jianchariqi;
    public CQUser() {
        super();
    }
    public CQUser(String name, String zhangtai, String qingkuang, Date jianchariqi) {
        super();
        this.name = name;
        this.zhangtai = zhangtai;
        this.qingkuang = qingkuang;
        this.jianchariqi = jianchariqi;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getzhangtai() {
        return zhangtai;
    }
    public void setzhangtai(String zhangtai) {
        this.zhangtai = zhangtai;
    }
    public String getqingkuang() {
        return qingkuang;
    }
    public void setqingkuang(String qingkuang) {
        this.qingkuang = qingkuang;
    }
    public Date getjianchariqi() {
        return jianchariqi;
    }
    public void setjianchariqi(Date jianchariqi) {
        this.jianchariqi = jianchariqi;
    }
    public void setjianchariqi(String jianchariqi) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(jianchariqi);
            this.jianchariqi=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.jianchariqi=null;
        }

    }
    @Override
    public String toString() {
        return "CQUser [id=" + id + ", name=" + name + ", zhangtai=" + zhangtai + ", qingkuang=" + qingkuang + ", jianchariqi=" + jianchariqi
                + "]";
    }
}