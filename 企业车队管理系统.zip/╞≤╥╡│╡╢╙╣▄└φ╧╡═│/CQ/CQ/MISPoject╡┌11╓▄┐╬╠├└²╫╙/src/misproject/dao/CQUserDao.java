package misproject.dao;

import misproject.pojo.CQUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 * 对CQUser表的浏览、查询、添加、修改、删除操作
 */
public class CQUserDao {
    /**
     * 对CQUser表的浏览操作
     */
    public static List<CQUser> allCQUsers() {
        List<CQUser> CQUsers=new ArrayList<CQUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from DY";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CQUser CQUser=new CQUser();
                CQUser.setId(rs.getInt("id"));
                CQUser.setName(rs.getString("name"));
                CQUser.setzhangtai(rs.getString("zhangtai"));
                CQUser.setqingkuang(rs.getString("qingkuang"));
                CQUser.setjianchariqi(rs.getDate("jianchariqi"));
                CQUsers.add(CQUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CQUsers;
    }
    /**
     * 对CQUser表的查询操作，按照name值查询
     */
    public static List<CQUser> queryCQUsersByName(String name) {
        List<CQUser> CQUsers=new ArrayList<CQUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from DY where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CQUser CQUser=new CQUser();
                CQUser.setId(rs.getInt("id"));
                CQUser.setName(rs.getString("name"));
                CQUser.setzhangtai(rs.getString("zhangtai"));
                CQUser.setqingkuang(rs.getString("qingkuang"));
                CQUser.setjianchariqi(rs.getDate("jianchariqi"));
                CQUsers.add(CQUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CQUsers;
    }
    /**
     * 对CQUser表的查询操作，按照name和zhangtai值查询
     */
    public static List<CQUser> queryCQUsersByNameAndzhangtai(String name,String zhangtai) {
        List<CQUser> CQUsers=new ArrayList<CQUser>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from DY where name like '%"+name+"%' and zhangtai='"+zhangtai+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                CQUser CQUser=new CQUser();
                CQUser.setId(rs.getInt("id"));
                CQUser.setName(rs.getString("name"));
                CQUser.setzhangtai(rs.getString("zhangtai"));
                CQUser.setqingkuang(rs.getString("qingkuang"));
                CQUser.setjianchariqi(rs.getDate("jianchariqi"));
                CQUsers.add(CQUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CQUsers;
    }
    /**
     * 对CQUser表的查询操作，按照id值查询
     */
    public static CQUser queryCQUsersById(int id) {
        JDBC jdbc=new JDBC();
        CQUser CQUser=null;
        try {
            jdbc.startConnection();
            String sql = "select * from  DY where id="+id;
            ResultSet rs=jdbc.query(sql);
            if(rs.next()) {
                CQUser=new CQUser();
                CQUser.setId(rs.getInt("id"));
                CQUser.setName(rs.getString("name"));
                CQUser.setzhangtai(rs.getString("zhangtai"));
                CQUser.setqingkuang(rs.getString("qingkuang"));
                CQUser.setjianchariqi(rs.getDate("jianchariqi"));
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return CQUser;
    }
    /**
     * 对CQUser表的添加操作
     */
    public static int insertCQUser(CQUser CQUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into DY(name,zhangtai,qingkuang,jianchariqi) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, CQUser.getName());
            pStatement.setString(2,CQUser.getzhangtai());
            pStatement.setString(3, CQUser.getqingkuang());
            pStatement.setDate(4, CQUser.getjianchariqi());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CQUser表的修改操作
     */
    public static int updateCQUserqingkuang(String qingkuang,int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update DY set qingkuang='"+qingkuang+"' where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CQUser表的修改操作
     */
    public static int updateCQUser(CQUser CQUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update DY set name=?,zhangtai=?,qingkuang=?,jianchariqi=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, CQUser.getName());
            pStatement.setString(2,CQUser.getzhangtai());
            pStatement.setString(3, CQUser.getqingkuang());
            pStatement.setDate(4, CQUser.getjianchariqi());
            pStatement.setInt(5, CQUser.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对CQUser表的删除操作
     */
    public static int deleteCQUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from DY where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
