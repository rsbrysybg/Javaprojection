CREATE TABLE `student` (
                           `Id` int NOT NULL AUTO_INCREMENT,
                           `name` varchar(20) DEFAULT NULL,
                           `sex` varchar(2) DEFAULT NULL,
                           `email` varchar(50) DEFAULT NULL,
                           `birthday` date DEFAULT NULL,
                           PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

# #如果表存在就删除表
# DROP TABLE IF EXISTS `student`;

CREATE TABLE `kecheng` (
                           `Id` INT NOT NULL AUTO_INCREMENT,
                           `name` VARCHAR(9) DEFAULT NULL,
                           `xuanke` VARCHAR(2) DEFAULT NULL,
                           `renkelaoshi` VARCHAR(50) DEFAULT NULL,
                           `kaoshishijian` DATE DEFAULT NULL,
                           PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
INSERT INTO `kecheng` VALUES ('1', '英语', '选修', '小刘', '1980-01-04');
INSERT INTO `kecheng` VALUES ('2', '数学', '必修', '校长', '1981-02-14');
INSERT INTO `kecheng` VALUES ('3', '语文', '必修', '效力', '1979-12-28');

# use vvv;
# DROP TABLE IF EXISTS `user`;
# drop table if exists `cars`;
use vms;
CREATE TABLE `User` (
                        `Id` INT NOT NULL AUTO_INCREMENT,
                        `name` VARCHAR(9) DEFAULT NULLUser,
                        `pas` VARCHAR(2) DEFAULT NULL,
                        `role` VARCHAR(50) DEFAULT NULL,
                        PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;