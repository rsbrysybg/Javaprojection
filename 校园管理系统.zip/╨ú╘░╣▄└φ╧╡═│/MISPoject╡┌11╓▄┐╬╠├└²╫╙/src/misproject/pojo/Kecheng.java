package misproject.pojo;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 数据表user的实体类
 */
public class Kecheng {
    private int id;
    private String name;
    private String xuanke;
    private String renkelaoshi;
    private Date kaoshishijian;
    public Kecheng() {
        super();
    }
    public Kecheng(String name, String xuanke, String renkelaoshi, Date kaoshishijian) {
        super();
        this.name = name;
        this.xuanke = xuanke;
        this.renkelaoshi = renkelaoshi;
        this.kaoshishijian = kaoshishijian;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getxuanke() {
        return xuanke;
    }
    public void setxuanke(String xuanke) {
        this.xuanke = xuanke;
    }
    public String getrenkelaoshi() {
        return renkelaoshi;
    }
    public void setrenkelaoshi(String renkelaoshi) {
        this.renkelaoshi = renkelaoshi;
    }
    public Date getkaoshishijian() {
        return kaoshishijian;
    }
    public void setkaoshishijian(Date kaoshishijian) {
        this.kaoshishijian = kaoshishijian;
    }
    public void setkaoshishijian(String kaoshishijian) {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date;
        try {
            date = format.parse(kaoshishijian);
            this.kaoshishijian=new Date(date.getTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            this.kaoshishijian=null;
        }

    }
    @Override
    public String toString() {
        return "TeacherUser [id=" + id + ", name=" + name + ", xuanke=" + xuanke + ", renkelaoshi=" + renkelaoshi + ", kaoshishijian=" + kaoshishijian
                + "]";
    }
}