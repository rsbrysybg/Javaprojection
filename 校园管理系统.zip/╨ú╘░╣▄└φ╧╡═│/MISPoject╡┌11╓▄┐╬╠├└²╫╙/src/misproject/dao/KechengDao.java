package misproject.dao;

import misproject.pojo.Kecheng;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 * 对TeacherUser表的浏览、查询、添加、修改、删除操作
 */
public class KechengDao {
    /**
     * 对TeacherUser表的浏览操作
     */
    public static List<Kecheng> allTeacherUsers() {
        List<Kecheng> TeacherUsers=new ArrayList<Kecheng>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from kecheng";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                Kecheng TeacherUser=new Kecheng();
                TeacherUser.setId(rs.getInt("id"));
                TeacherUser.setName(rs.getString("name"));
                TeacherUser.setxuanke(rs.getString("xuanke"));
                TeacherUser.setrenkelaoshi(rs.getString("renkelaoshi"));
                TeacherUser.setkaoshishijian(rs.getDate("kaoshishijian"));
                TeacherUsers.add(TeacherUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return TeacherUsers;
    }
    /**
     * 对TeacherUser表的查询操作，按照name值查询
     */
    public static List<Kecheng> queryTeacherUsersByName(String name) {
        List<Kecheng> TeacherUsers=new ArrayList<Kecheng>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from kecheng where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                Kecheng TeacherUser=new Kecheng();
                TeacherUser.setId(rs.getInt("id"));
                TeacherUser.setName(rs.getString("name"));
                TeacherUser.setxuanke(rs.getString("xuanke"));
                TeacherUser.setrenkelaoshi(rs.getString("renkelaoshi"));
                TeacherUser.setkaoshishijian(rs.getDate("kaoshishijian"));
                TeacherUsers.add(TeacherUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return TeacherUsers;
    }
    /**
     * 对TeacherUser表的查询操作，按照name和xuanke值查询
     */
    public static List<Kecheng> queryTeacherUsersByNameAndxuanke(String name, String xuanke) {
        List<Kecheng> TeacherUsers=new ArrayList<Kecheng>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from kecheng where name like '%"+name+"%' and xuanke='"+xuanke+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                Kecheng TeacherUser=new Kecheng();
                TeacherUser.setId(rs.getInt("id"));
                TeacherUser.setName(rs.getString("name"));
                TeacherUser.setxuanke(rs.getString("xuanke"));
                TeacherUser.setrenkelaoshi(rs.getString("renkelaoshi"));
                TeacherUser.setkaoshishijian(rs.getDate("kaoshishijian"));
                TeacherUsers.add(TeacherUser);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return TeacherUsers;
    }
    /**
     * 对TeacherUser表的添加操作
     */
    public static int insertTeacherUser(Kecheng TeacherUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into kecheng(name,xuanke,renkelaoshi,kaoshishijian) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, TeacherUser.getName());
            pStatement.setString(2,TeacherUser.getxuanke());
            pStatement.setString(3, TeacherUser.getrenkelaoshi());
            pStatement.setDate(4, TeacherUser.getkaoshishijian());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对TeacherUser表的修改操作
     */
    public static int updateTeacherUser(Kecheng TeacherUser) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update kecheng set name=?,xuanke=?,renkelaoshi=?,kaoshishijian=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, TeacherUser.getName());
            pStatement.setString(2,TeacherUser.getxuanke());
            pStatement.setString(3, TeacherUser.getrenkelaoshi());
            pStatement.setDate(4, TeacherUser.getkaoshishijian());
            pStatement.setInt(5, TeacherUser.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对TeacherUser表的删除操作
     */
    public static int deleteTeacherUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from kecheng where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
