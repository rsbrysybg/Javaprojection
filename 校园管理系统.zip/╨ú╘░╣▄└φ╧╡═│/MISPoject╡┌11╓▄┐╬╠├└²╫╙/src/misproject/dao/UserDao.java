package misproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import misproject.pojo.User;


/**
 * 对user表的浏览、查询、添加、修改、删除操作
 */
public class UserDao {
    /**
     * 对user表的浏览操作
     */
    public static List<User> allUsers() {
        List<User> users=new ArrayList<User>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from student";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                User user=new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setSex(rs.getString("sex"));
                user.setEmail(rs.getString("email"));
                user.setBirthday(rs.getDate("birthday"));
                users.add(user);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return users;
    }
    /**
     * 对user表的查询操作，按照name值查询
     */
    public static List<User> queryUsersByName(String name) {
        List<User> users=new ArrayList<User>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from  student where name like '%"+name+"%'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                User user=new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setSex(rs.getString("sex"));
                user.setEmail(rs.getString("email"));
                user.setBirthday(rs.getDate("birthday"));
                users.add(user);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return users;
    }
    /**
     * 对user表的查询操作，按照name和sex值查询
     */
    public static List<User> queryUsersByNameAndSex(String name,String sex) {
        List<User> users=new ArrayList<User>();
        JDBC jdbc=new JDBC();
        try {
            jdbc.startConnection();
            String sql = "select * from student where name like '%"+name+"%' and sex='"+sex+"'";
            ResultSet rs=jdbc.query(sql);
            while(rs.next()) {
                User user=new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setSex(rs.getString("sex"));
                user.setEmail(rs.getString("email"));
                user.setBirthday(rs.getDate("birthday"));
                users.add(user);
            }
            rs.close();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        return users;
    }
    /**
     * 对user表的添加操作
     */
    public static int insertuser(User user) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql = "insert into student(name,sex,email,birthday) values (?,?,?,?)";
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, user.getName());
            pStatement.setString(2,user.getSex());
            pStatement.setString(3, user.getEmail());
            pStatement.setDate(4, user.getBirthday());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对user表的修改操作
     */
    public static int updateUser(User user) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="update student set name=?,sex=?,email=?,birthday=? where id=?";
            System.out.println(sql);
            Connection connection=jdbc.getConnection();
            PreparedStatement pStatement=connection.prepareStatement(sql);
            pStatement.setString(1, user.getName());
            pStatement.setString(2,user.getSex());
            pStatement.setString(3, user.getEmail());
            pStatement.setDate(4, user.getBirthday());
            pStatement.setInt(5, user.getId());
            System.out.println(sql);
            result=pStatement.executeUpdate();
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
    /**
     * 对user表的删除操作
     */
    public static int deleteUserById(int id) {
        JDBC jdbc=new JDBC();
        int result=0;
        try {
            jdbc.startConnection();
            String sql="delete from student where id="+id;
            System.out.println(sql);
            result=jdbc.update(sql);
            jdbc.stopConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
        return result;
    }
}
